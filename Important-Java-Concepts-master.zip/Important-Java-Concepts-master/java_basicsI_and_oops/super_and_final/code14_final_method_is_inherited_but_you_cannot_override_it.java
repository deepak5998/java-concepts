class Bike{  
  final void run(){System.out.println("running...");}  
}  

class Honda2 extends Bike{  
   public static void main(String args[]){  
    new Honda2().run();  
   }  
}  