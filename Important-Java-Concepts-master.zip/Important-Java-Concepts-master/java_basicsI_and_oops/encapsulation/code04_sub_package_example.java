// A java package is a group of similar types of 
// classes, interfaces and sub-packages.

package com.pak.core;  
class Simple{  
  public static void main(String args[]){  
   System.out.println("Hello subpackage");  
  }  
} 