// putting two public classes in a package

// ------------------- FILE 1 --------------------

//save as A.java  
  
package pak;  
public class A{}  

// ------------------- FILE 2 --------------------

//save as B.java  
  
package pak;  
public class B{}  