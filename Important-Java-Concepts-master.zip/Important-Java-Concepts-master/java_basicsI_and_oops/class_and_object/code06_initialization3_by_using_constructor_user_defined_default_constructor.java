// Constructor in java is a special type of method that is used to initialize the object.
// A constructor that have no parameter is known as default constructor.

class Bike1{  
 Bike1() {
  System.out.println("Bike is created");
 }

 public static void main(String args[]) {  
  Bike1 b=new Bike1();  
 }  
}  