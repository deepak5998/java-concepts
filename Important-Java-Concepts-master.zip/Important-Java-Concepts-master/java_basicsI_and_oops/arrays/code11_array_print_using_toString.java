// Java program to demonstrate that we can print
// array elements in a single line
import java.util.Arrays;

public class Main
{
	public static void main(String[] args)
	{
		int ar[] = {4, 6, 1, 8, 3, 9, 7, 4, 2};
		
		// To print the elements in one line
		System.out.println(Arrays.toString(ar));
	}
}
